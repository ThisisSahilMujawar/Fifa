# Fifa2022
JS Practical
JS1: The student will be able to :Demonstrate working of Javascript code.Create basic JS scripts 
using proper syntax. -> 
JS2 -> The aim of this experiment is to understand the concept of if statement and use if statement 
in simple js ->
JS3: Write a JavaScript program to calculate area of triangle, area of rectangle and area of
circle. -> Area.html
JS4: Write a JavaScript program to generate the multiplication table of a given number. -> Multiply.html
JS5: Write a JavaScript program to following operations on a given string, • Reverse string •
Replace characters of a string. • String is Palindrome. -> String.html
JS6: Create an array and perform different operations on it -> Array.html
JS7: Appending Object to array and check if an object is an array -> Append.html
JS8: Write a JavaScript program to compare two strings using various methods. -> TwoString.html
JS9: Write a JavaScript program that will create a countdown timer. -> Countdown.html
JS10: Write a JavaScript program to create a Home page of any website and change background color using -
On mouse over event, On focus event -> home.html
JS11: Create a student information Form to accept information like Name, Address, City, State Gender, Mobile 
Number, and email id. Perform validations for: form.html
